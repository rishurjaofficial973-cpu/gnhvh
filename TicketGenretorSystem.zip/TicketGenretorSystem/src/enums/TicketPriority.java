package enums;

public enum TicketPriority {
    // ABSTRACTION
    // Priority values ko readable aur controlled banata hai

    LOW,
    MEDIUM,
    HIGH
}
